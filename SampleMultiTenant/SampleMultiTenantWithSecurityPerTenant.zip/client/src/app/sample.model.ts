export interface Order {
  Id: number;
  UserName: string;
  OrderDate: string;
  OrderDetails: Array<OrderDetail>;
}

export interface OrderDetail {
  Id: number;
  Quantity: number;
  OrderId: number;
  ProductId: number;
}

export interface Product {
  Id: number;
  ProductName: string;
  ProductPrice: number;
  ProductPicture: string;
  OrderDetails: Array<OrderDetail>;
}
