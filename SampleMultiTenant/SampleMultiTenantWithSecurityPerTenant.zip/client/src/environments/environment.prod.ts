export const environment = {
  sample: 'http://localhost:5000/odata/Sample',

  securityUrl: 'http://localhost:5000/auth',
  production: true
};
